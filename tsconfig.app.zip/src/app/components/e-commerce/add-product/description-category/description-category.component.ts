import { Component } from '@angular/core';

@Component({
  selector: 'app-description-category',
  templateUrl: './description-category.component.html',
  styleUrls: ['./description-category.component.scss']
})
export class DescriptionCategoryComponent {

}
