import { Component } from '@angular/core';

@Component({
  selector: 'app-form-builder2',
  templateUrl: './form-builder2.component.html',
  styleUrls: ['./form-builder2.component.scss']
})
export class FormBuilder2Component {

}
