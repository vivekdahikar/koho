import { Component } from '@angular/core';

@Component({
  selector: 'app-button-builder',
  templateUrl: './button-builder.component.html',
  styleUrls: ['./button-builder.component.scss']
})
export class ButtonBuilderComponent {

}
