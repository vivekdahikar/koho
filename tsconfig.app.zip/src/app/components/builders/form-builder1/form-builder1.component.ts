import { Component } from '@angular/core';

@Component({
  selector: 'app-form-builder1',
  templateUrl: './form-builder1.component.html',
  styleUrls: ['./form-builder1.component.scss']
})
export class FormBuilder1Component {

}
