import { Component } from '@angular/core';

@Component({
  selector: 'app-view-html',
  templateUrl: './view-html.component.html',
  styleUrls: ['./view-html.component.scss']
})
export class ViewHtmlComponent {

}
