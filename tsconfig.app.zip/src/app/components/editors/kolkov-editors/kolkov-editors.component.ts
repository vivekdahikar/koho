import { Component } from '@angular/core';

@Component({
  selector: 'app-kolkov-editors',
  templateUrl: './kolkov-editors.component.html',
  styleUrls: ['./kolkov-editors.component.scss'],
})
export class KolkovEditorsComponent {
  public htmlContent = '';
}
