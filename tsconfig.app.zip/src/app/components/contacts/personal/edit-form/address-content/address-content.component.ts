import { Component } from '@angular/core';

@Component({
  selector: 'app-address-content',
  templateUrl: './address-content.component.html',
  styleUrls: ['./address-content.component.scss']
})
export class AddressContentComponent {

}
