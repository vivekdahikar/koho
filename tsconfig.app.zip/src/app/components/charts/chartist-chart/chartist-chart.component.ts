import { Component } from '@angular/core';

@Component({
  selector: 'app-chartist-chart',
  templateUrl: './chartist-chart.component.html',
  styleUrls: ['./chartist-chart.component.scss']
})
export class ChartistChartComponent {

}
