import { Component } from '@angular/core';

@Component({
  selector: 'app-pagination-active-disabled',
  templateUrl: './pagination-active-disabled.component.html',
  styleUrls: ['./pagination-active-disabled.component.scss']
})
export class PaginationActiveDisabledComponent {

}
