import { Component } from '@angular/core';

@Component({
  selector: 'app-step-sizing',
  templateUrl: './step-sizing.component.html',
  styleUrls: ['./step-sizing.component.scss']
})
export class StepSizingComponent {

}
