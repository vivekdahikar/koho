import { Component } from '@angular/core';

@Component({
  selector: 'app-default-step',
  templateUrl: './default-step.component.html',
  styleUrls: ['./default-step.component.scss']
})
export class DefaultStepComponent {

}
