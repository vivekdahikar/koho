import { Component } from '@angular/core';

@Component({
  selector: 'app-step-icon',
  templateUrl: './step-icon.component.html',
  styleUrls: ['./step-icon.component.scss']
})
export class StepIconComponent {

}
