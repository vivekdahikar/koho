import { Component } from '@angular/core';

@Component({
  selector: 'app-default-pearls-steps',
  templateUrl: './default-pearls-steps.component.html',
  styleUrls: ['./default-pearls-steps.component.scss']
})
export class DefaultPearlsStepsComponent {

}
