import { Component } from '@angular/core';

@Component({
  selector: 'app-step-states',
  templateUrl: './step-states.component.html',
  styleUrls: ['./step-states.component.scss']
})
export class StepStatesComponent {

}
