import { Component } from '@angular/core';

@Component({
  selector: 'app-card-with-border',
  templateUrl: './card-with-border.component.html',
  styleUrls: ['./card-with-border.component.scss']
})
export class CardWithBorderComponent {

}
