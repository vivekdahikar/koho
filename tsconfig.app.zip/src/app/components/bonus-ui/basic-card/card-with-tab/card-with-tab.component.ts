import { Component } from '@angular/core';

@Component({
  selector: 'app-card-with-tab',
  templateUrl: './card-with-tab.component.html',
  styleUrls: ['./card-with-tab.component.scss']
})
export class CardWithTabComponent {

}
