import { Component } from '@angular/core';

@Component({
  selector: 'app-email-filter',
  templateUrl: './email-filter.component.html',
  styleUrls: ['./email-filter.component.scss']
})
export class EmailFilterComponent {

}
