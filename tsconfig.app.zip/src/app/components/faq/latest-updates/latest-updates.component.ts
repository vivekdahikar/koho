import { Component } from '@angular/core';

@Component({
  selector: 'app-latest-updates',
  templateUrl: './latest-updates.component.html',
  styleUrls: ['./latest-updates.component.scss']
})
export class LatestUpdatesComponent {

}
