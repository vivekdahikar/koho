import { Component } from '@angular/core';

@Component({
  selector: 'app-quick-ques-and-ans',
  templateUrl: './quick-ques-and-ans.component.html',
  styleUrls: ['./quick-ques-and-ans.component.scss'],
})
export class QuickQuesAndAnsComponent {
  public isCollapsed = true;
  public isCollapsed2 = true;
  public isCollapsed3 = true;
  public isCollapsed4 = true;
  public isCollapsed5 = true;
  constructor() {}
}
