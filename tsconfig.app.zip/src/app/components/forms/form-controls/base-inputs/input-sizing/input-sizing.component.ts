import { Component } from '@angular/core';

@Component({
  selector: 'app-input-sizing',
  templateUrl: './input-sizing.component.html',
  styleUrls: ['./input-sizing.component.scss']
})
export class InputSizingComponent {

}
