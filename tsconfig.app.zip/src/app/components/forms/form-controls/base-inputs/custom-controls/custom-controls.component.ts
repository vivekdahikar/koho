import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-controls',
  templateUrl: './custom-controls.component.html',
  styleUrls: ['./custom-controls.component.scss']
})
export class CustomControlsComponent {

}
