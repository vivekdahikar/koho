import { Component } from '@angular/core';

@Component({
  selector: 'app-base-inputs',
  templateUrl: './base-inputs.component.html',
  styleUrls: ['./base-inputs.component.scss']
})
export class BaseInputsComponent {

}
