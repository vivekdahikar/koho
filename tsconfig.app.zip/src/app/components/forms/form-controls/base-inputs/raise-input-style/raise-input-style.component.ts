import { Component } from '@angular/core';

@Component({
  selector: 'app-raise-input-style',
  templateUrl: './raise-input-style.component.html',
  styleUrls: ['./raise-input-style.component.scss']
})
export class RaiseInputStyleComponent {

}
