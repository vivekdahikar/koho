import { Component } from '@angular/core';

@Component({
  selector: 'app-inline-style',
  templateUrl: './inline-style.component.html',
  styleUrls: ['./inline-style.component.scss']
})
export class InlineStyleComponent {

}
