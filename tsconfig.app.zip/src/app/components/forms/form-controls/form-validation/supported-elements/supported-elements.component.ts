import { Component } from '@angular/core';

@Component({
  selector: 'app-supported-elements',
  templateUrl: './supported-elements.component.html',
  styleUrls: ['./supported-elements.component.scss']
})
export class SupportedElementsComponent {

}
