import { Component } from '@angular/core';

@Component({
  selector: 'app-basic-input-groups2',
  templateUrl: './basic-input-groups2.component.html',
  styleUrls: ['./basic-input-groups2.component.scss']
})
export class BasicInputGroups2Component {

}
