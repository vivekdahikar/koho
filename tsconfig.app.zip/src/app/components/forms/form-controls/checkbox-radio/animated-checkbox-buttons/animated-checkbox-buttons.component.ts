import { Component } from '@angular/core';

@Component({
  selector: 'app-animated-checkbox-buttons',
  templateUrl: './animated-checkbox-buttons.component.html',
  styleUrls: ['./animated-checkbox-buttons.component.scss']
})
export class AnimatedCheckboxButtonsComponent {

}
