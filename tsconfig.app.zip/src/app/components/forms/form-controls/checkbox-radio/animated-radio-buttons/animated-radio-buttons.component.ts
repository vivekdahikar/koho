import { Component } from '@angular/core';

@Component({
  selector: 'app-animated-radio-buttons',
  templateUrl: './animated-radio-buttons.component.html',
  styleUrls: ['./animated-radio-buttons.component.scss']
})
export class AnimatedRadioButtonsComponent {

}
